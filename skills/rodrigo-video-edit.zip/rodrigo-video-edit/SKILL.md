---
name: rodrigo-video-edit
description: Base de edição aprovada para os vídeos de marca pessoal do Rodrigo (Viral Wave Agency) — corte, escolha de takes, legendas premium, motion graphics, som e entrega para o CapCut. Usar SEMPRE que o Rodrigo pedir para editar, cortar, legendar ou pôr motion graphics num vídeo seu (talking head, reels, TikTok, UGC de marca pessoal em português).
---

# Guia de estilo — vídeos do Rodrigo (Viral Wave Agency)

> **BASE APROVADA (vídeos de marca pessoal em português):** o vídeo "Dizer não a clientes" v2/v3 é o padrão. Todos os vídeos seguem esta base, mas cada um tem de ter **diferenças** nos gráficos e motion graphics — nunca copiar os mesmos elementos.

Regras para qualquer edição dos meus vídeos. Objetivo: **premium, estético e cinematográfico** — nunca "jogado".

## Corte
- **Sem frases repetidas.** Quando há vários takes, escolher o melhor por **entoação** (energia, variação de tom, final firme) e por **cara** (olhar para a câmara, expressão confiante, sem olhos fechados/caretas). Nunca usar takes com hesitações a meio.
- Não perder o fio condutor. Se o hook repete uma frase do fim, escolher outro hook.
- Corte **bem apertado** entre frases; pausas dramáticas curtas (ex.: antes de "chega") podem ficar.
- Vídeo final a **1.1x** (áudio com o tom preservado).
- **Final com CTA de mão:** se no fim eu levo a mão à câmara, manter o gesto e **cortar exatamente quando a mão chega à câmara**.

## Imagem
- **Não mexer na cor** — faço eu a cor. Trabalhar sempre em 10-bit quando o original é 10-bit (DJI).
- Entregar: versão final completa + **plate sem texto (10-bit)** + **camada de texto com transparência em ProRes 4444** (funciona no CapCut) + áudio (mix e stems).
- Tudo dentro das **margens seguras** do Reels/TikTok (1080×1920: 250 px em cima, 480 px em baixo, 120 px à direita, 60 px à esquerda). Verificar frame a frame.
- Zooms: poucos, suaves, **sempre centrados na cara**.

## Legendas (inspiração: Jack Mason, Bradford Marais)
- **1 a 3 palavras de cada vez**, à altura do peito (sobre a roupa, alto contraste), não sempre no mesmo sítio fixo em cima.
- **Roupa clara (t-shirt branca):** legendas **em cima, sobre a parede** (branco + âmbar), nunca em cima da t-shirt. Na dúvida, fazer um print de teste e mandar.
- **Centrar no meio do ecrã (x = 540)** com **120 px de margem dos dois lados** (máx. 840 px de largura) — não centrar entre as margens assimétricas, fica puxado para a esquerda.
- **Hierarquia de duas escalas:** etiqueta pequena (Inter Bold, maiúsculas, espaçada) + palavra grande (condensada bold, maiúsculas, tracking apertado).
- **Itálico serifado** (Instrument Serif) para palavras emocionais/elegantes, em minúsculas.
- **Cor de destaque tirada da cena** (no meu escritório: âmbar/dourado do relógio `#F2B24C`); números e palavras-chave nessa cor. Nada de cores aleatórias.
- Animação subtil: fade + subida curta + desfoque a desaparecer; palavras-herói com "tracking in".
- **Profundidade:** palavras-herói grandes **atrás de mim** (recorte da silhueta) em momentos-chave (hook, clímax).

## Espaço de cima (acima da cabeça) — com moderação
- Usar o espaço de cima só em **momentos-chave** (ex.: os "não" espalhados à volta da cabeça, palavras de profundidade no hook/clímax). **Não** encher todas as frases com ícones/elementos em cima — fica demasiado.
- As legendas ficam ao peito.

## Entradas com impacto
- Palavras-herói **entram** (arrastadas/deslizadas com rasto de movimento), nunca aparecem já paradas; som de arrasto (whoosh) + impacto + pequeno abanão de câmara ao aterrar.

## Tempo de leitura dos gráficos
- Cada gráfico/ecrã tem de ficar **completo e parado pelo menos ~0,8–1 s** antes de sair — acelerar as animações de construção em vez de cortar o final.

## Motion graphics — variar, nunca repetir a mesma fórmula
Escolher por momento, no máximo 2–3 recursos diferentes por vídeo:
| Situação | Recurso |
|---|---|
| Hook / clímax | Palavra gigante atrás de mim (profundidade) + impacto sonoro — **não usar sempre no hook, variar** |
| Lista, passos, "antes vs depois", números | **Ecrã editorial**: papel quadriculado creme, tiras de papel rasgado com texto serifado, marcador âmbar e gráficos desenhados à mão |
| Citação / frase marcante | **Citação cinematográfica**: o **meu próprio plano** por trás, desfocado e escurecido (nunca um fundo de cor), texto serifado grande, riscos/círculos desenhados à mão |
| Mostrar exemplos de conteúdo/produtos | Ecrã claro (off-white) com mockups de telemóvel e sombra suave |
| Repetição/ênfase ("mais vezes não") | Palavras espalhadas na cena (**esporádico, 3–4 no máximo**), várias escalas e opacidades, **sempre atrás de mim** |
| CTA "guarda/comenta" | Ícone nativo do Instagram animado (guardar, comentário) |
- **Nunca** ecrãs azul-escuro com tabelas/cartões/UI — "vê-se que é AI". Tudo **cinematográfico e clean**.
- **Nada à frente da minha cara.** Qualquer palavra/elemento que se cruze com a cabeça vai para trás de mim (recorte da silhueta).
- Gráficos de números (ex.: mais clientes ↑ vs faturação ↓) = **gráfico desenhado à mão** no ecrã editorial (tinta preta + marcador âmbar, círculo à mão no ponto-chave).

## Referências (cortes, legendas, motion)
- https://www.instagram.com/reel/DXT4_AUJGGm/ — ecrã editorial (papel quadriculado, tiras rasgadas, gráfico à mão), legendas pequenas bold + itálico
- https://www.instagram.com/reel/DRpAdkyETBs/ — legendas 1–3 palavras ao peito, palavras atrás do sujeito, look cinematográfico
- https://www.instagram.com/reel/DBqaWrLttT_/ — legenda simples ao peito, 1 palavra de cada vez, âmbar só em números

## Som
- Voz a **-14 LUFS**. Efeitos discretos por baixo da voz (whooshes nas transições, papel a deslizar, marcador a riscar, impacto nas palavras-herói). Sem música sem licença.

## Fluxo de trabalho
1. Transcrever (Whisper large-v3, pt) com tempos por palavra; verificar zonas com som que a transcrição saltou.
2. Agrupar takes por frase; escolher o melhor (entoação medida + frames da cara); corte apertado; 1.1x; confirmar com nova transcrição.
3. Mandar **pré-visualização 1080p** para aprovação.
4. Final 4K: plate 10-bit + texto ProRes 4444 alpha + áudio separado + versão completa. Verificar margens seguras frame a frame.

## Fluxo com vídeo já cortado e graduado (preferido)
- Recebo o corte final já graduado (4K, 10-bit, com som). **Não re-codifico o vídeo.**
- Entrego: texto em **ProRes 4444 com alpha** (mesmos fps do vídeo), áudio (mix final + voz, música e efeitos em separado) e, se houver fundo desfocado, um **clip curto desfocado com alpha** para pôr por cima no tempo indicado.
- Música: das músicas de fundo na Drive, variar de vídeo para vídeo. Nível: voz -14 LUFS, **música ≈ -32,7 LUFS** (igual ao mix aprovado), a baixar ~3 dB quando falo.
